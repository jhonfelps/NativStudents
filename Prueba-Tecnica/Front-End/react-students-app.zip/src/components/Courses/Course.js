export class Course{
    constructor(id,nombre, horario, fecha_inicio, fecha_fin, numero_estudiantes) {
      this.id = id;
      this.nombre = nombre;
      this.horario = horario;
      this.fecha_inicio = fecha_inicio;
      this.fecha_fin = fecha_fin;
      this.numero_estudiantes = numero_estudiantes;
    }
}